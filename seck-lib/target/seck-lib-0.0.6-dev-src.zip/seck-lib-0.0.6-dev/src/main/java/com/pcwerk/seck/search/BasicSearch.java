package com.pcwerk.seck.search;

public class BasicSearch extends Search{

	
	
}
