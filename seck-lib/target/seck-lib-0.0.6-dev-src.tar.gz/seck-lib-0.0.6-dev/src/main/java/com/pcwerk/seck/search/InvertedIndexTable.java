package com.pcwerk.seck.search;

public class InvertedIndexTable {

}
