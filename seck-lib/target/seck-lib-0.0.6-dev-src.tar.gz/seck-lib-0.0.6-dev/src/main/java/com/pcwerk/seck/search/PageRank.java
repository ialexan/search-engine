package com.pcwerk.seck.search;

import java.util.LinkedHashMap;

public class PageRank implements RankingMechanism{

	public LinkedHashMap<String, Double> rank(Object o) {
		// TODO Auto-generated method stub
		return null;
	}

}
