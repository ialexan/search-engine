package com.pcwerk.seck.search;

import java.util.LinkedHashMap;

public class LinkAnalysis implements RankingMechanism{

	public LinkedHashMap<String, Double> rank(Object o) {
		// TODO Auto-generated method stub
		return null;
	}

}
