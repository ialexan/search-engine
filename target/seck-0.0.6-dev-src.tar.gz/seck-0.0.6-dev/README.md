SECK
====

Search Engine Construction Kit

Current version: 0.0.5

For more information on this project, please visit the [SECK wiki] (https://github.com/pcwerk/seck/wiki).

## Change Log 

### version 0.0.1

* Basic skeleton for SECK with support for maven; initial release

### version 0.0.2

* Reorganize maven to do top level maven commands
* Initial support for RESTlet

### version 0.0.3

* Add getopt support to main application; refactor main application to be the frontend driver for all the sub applications
* Trim fatty stuff in pom.xml files

### version 0.0.4

* Standalone App that parses commandline arguments

### version 0.0.5

* Hadoop cluster builder with vagrant and virtualbox, courtesy of http://java.dzone.com/articles/setting-hadoop-virtual-cluster

### version 0.0.6-dev

* Index app
* Big table data structure
* Search class interface
