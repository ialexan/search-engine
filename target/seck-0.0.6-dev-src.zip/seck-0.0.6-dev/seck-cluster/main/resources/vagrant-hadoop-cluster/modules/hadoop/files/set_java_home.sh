export JAVA_HOME="/usr/lib/jvm/java-1.6.0-openjdk-amd64"
