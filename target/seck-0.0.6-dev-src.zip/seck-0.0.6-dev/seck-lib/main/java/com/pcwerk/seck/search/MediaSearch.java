package com.pcwerk.seck.search;

public class MediaSearch extends Search{

}
